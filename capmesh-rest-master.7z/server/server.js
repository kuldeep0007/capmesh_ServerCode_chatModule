const express = require('express')
const app = express()
var parser = require('body-parser');

const Dao = require('./modules/data-access/data-access')
const dao = new Dao();

const Chats = require('./modules/chatModule/chats');
const chats = new Chats();


app.use(parser.json());


// insert new conversation if not exist else add message in older conversation
app.post('/rest/api/chats/addChatsBetweenUsers/', async (req, res) => {
    let user1 = (req.body).user1;
    let user2 = (req.body).user2;
    let sender = (req.body).sender;
    let content = (req.body).content;
    let previousConversationStatus = await chats.conversationExist(user1,user2);
    if (previousConversationStatus) {
        var result = await chats.addMessageInConversation(user1, user2, sender, content);
        res.send(result);
    }
    else {
        let result = await chats.newConversation(user1, user2, sender, content);
        res.send(result);
    }
})
//get chats between two user1 and user2
app.post('/rest/api/chats/getchatsBetweenUsers/', async (req, res) => {
    let user1 = (req.body).user1;
    let user2 = (req.body).user2;
    let result = await chats.getChatsBetweenUsers(user1, user2)
    res.send(result)
})






app.listen('8080', () => console.log('Listening on port 8080'))