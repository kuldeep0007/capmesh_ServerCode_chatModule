var Dao = require('../data-access/data-access')
const dao = new Dao()

class Chats {
    //function to get chats beyween two users-user1 and user2
    async getChatsBetweenUsers(user1, user2) {
        let result = await dao.aggregate("conversations", [{ $match: { participants: { $all: [user1, user2] } } }, { $project: { _id: 0, messages: 1 } }])
        return result[0].messages
    }
    //function to find if there is any previous conversation
    async conversationExist(user1,user2){
        let result = await dao.find("conversations", { participants: { $all: [user1, user2] } });
         if(result.length===0){
             return false;
         }else{
             return true;
         }
    }
    //function to start a new Conversation..insert a new conversation
    async newConversation(user1,user2,sender,content){
        let result = await dao.insert("conversations", { "participants": [user1, user2], "messages": [{ "sender": sender, "content": content, timestamp: new Date() }] });
        return result;
    }
    //function to  add message in a chat that already exist
    async addMessageInConversation(user1,user2,sender,content){
        var result = await dao.update("conversations", { participants: { $all: [user1, user2] } }, { $push: { "messages": { "sender": sender, "content": content, "timestamp": new Date() } } });
        return result;
    }
}

module.exports = Chats;